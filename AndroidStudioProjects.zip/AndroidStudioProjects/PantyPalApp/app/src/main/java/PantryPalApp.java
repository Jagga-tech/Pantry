public class PantryPalApp {
}
