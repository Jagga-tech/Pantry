package com.example.homeactivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView tv = findViewById(R.id.tvWelcome);
        String email = getIntent().getStringExtra("userEmail");
        if (email != null) {
            tv.setText("Welcome to PantryPal, " + email + "!");
        }

        Button logout = findViewById(R.id.btnLogout);
        logout.setOnClickListener(v -> finish()); // goes back to LoginActivity
    }
}
